# iPhone Duo Launcher — Xperia 1 V / Android 15

Native Android HOME launcher prototype inspired by the supplied iPhone Duo / Liquid Glass reference.

## Target device
- Sony Xperia 1 V
- Android 15 / targetSdk 35
- Portrait-first responsive layout for the 6.5-inch 21:9 display
- Layout uses Android density-independent pixels and system-bar insets, not raw 4K pixel coordinates.

## Current prototype (v0.4.0-xperia1v)
- Registers as an Android Home app (`MAIN` + `HOME` + `DEFAULT`).
- Uses `LauncherApps` to enumerate and launch launchable activities.
- Searchable app library with 4/5-column responsive grid.
- Translucent glass-style category panels and a right-side dock.
- Category panels filter likely matching apps (social, tools, productivity/finance, suggestions).
- Long-press an app to add/remove it from the dock or open Android App info.
- Dock selection is saved locally.
- Uses transparent system bars and applies system-bar insets for Android 15 edge-to-edge behavior.
- Folder tiles are category shortcuts in this prototype; user-managed folder contents and drag-and-drop are not implemented yet.

## Build APK
Requires Android Studio, JDK 17, Android SDK Platform 35, and Gradle 8.9+.
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated debug APK on the Xperia 1 V.
5. Choose **iPhone Duo Launcher** as the Home app when prompted, or use **Settings > Apps > Default apps > Home app**.

## Validation status
The source project has not been compiled or tested on a physical Xperia 1 V in this environment. A generated APK is not included.
