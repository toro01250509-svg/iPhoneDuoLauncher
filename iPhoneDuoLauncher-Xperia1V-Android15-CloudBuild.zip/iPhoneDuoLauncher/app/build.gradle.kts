plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iphoneduo.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.iphoneduo.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0-xperia1v"
    }
}
