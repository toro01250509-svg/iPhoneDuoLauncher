package com.iphoneduo.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private var allApps: List<LauncherActivityInfo> = emptyList()
    private var drawerOpen = false
    private var drawerQuery = ""
    private var drawerCategory: String? = null
    private val dockPackages = linkedSetOf<String>()
    private val prefs by lazy { getSharedPreferences("duo_launcher", MODE_PRIVATE) }
    private val launcherApps by lazy { getSystemService(LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        run { window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN }
        dockPackages.addAll(prefs.getStringSet("dock", emptySet()) ?: emptySet())
        loadApps()
        buildHome()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        if (::root.isInitialized) {
            if (drawerOpen) showDrawer(drawerQuery, drawerCategory) else buildHome()
        }
    }

    private fun loadApps() {
        allApps = launcherApps.getActivityList(null, Process.myUserHandle())
            .sortedBy { it.label.toString().lowercase(Locale.getDefault()) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun glass(radius: Float = 26f, alpha: Int = 78): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radius).toFloat()
        setColor(Color.argb(alpha, 245, 246, 250))
        setStroke(dp(1), Color.argb(95, 255, 255, 255))
    }

    private fun label(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

    private fun makeRoot(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(57, 51, 64), Color.rgb(25, 25, 34), Color.rgb(49, 39, 46)))
            setOnApplyWindowInsetsListener { view, insets ->
                @Suppress("DEPRECATION")
                val top = if (android.os.Build.VERSION.SDK_INT >= 30) insets.getInsets(WindowInsets.Type.systemBars()).top else insets.systemWindowInsetTop
                @Suppress("DEPRECATION")
                val bottom = if (android.os.Build.VERSION.SDK_INT >= 30) insets.getInsets(WindowInsets.Type.systemBars()).bottom else insets.systemWindowInsetBottom
                view.setPadding(dp(16), dp(12) + top, dp(16), dp(10) + bottom)
                insets
            }
        }
        setContentView(root)
        return root
    }

    private fun buildHome() {
        drawerOpen = false
        makeRoot()
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 27f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(header)

        search = EditText(this).apply {
            hint = "⌕  App 資源庫"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            singleLine = true
            setPadding(dp(16), 0, dp(16), 0)
            background = glass(22f, 70)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10); bottomMargin = dp(14) })

        val scroll = ScrollView(this).apply { clipToPadding = false }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        val folderColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tileHeight = (resources.configuration.screenHeightDp / 5).coerceIn(136, 176)
        val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        firstRow.addView(folder("建議", listOf("設定", "Play 商店", "相簿", "LINE")), LinearLayout.LayoutParams(0, dp(tileHeight), 1f).apply { rightMargin = dp(6) })
        firstRow.addView(folder("效率與財務", listOf("行事曆", "計算機", "檔案", "銀行")), LinearLayout.LayoutParams(0, dp(tileHeight), 1f).apply { leftMargin = dp(6) })
        folderColumn.addView(firstRow)
        val secondRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        secondRow.addView(folder("社交", listOf("LINE", "Facebook", "Instagram", "Gmail")), LinearLayout.LayoutParams(0, dp(tileHeight), 1f).apply { rightMargin = dp(6); topMargin = dp(12) })
        secondRow.addView(folder("工具", listOf("檔案", "時鐘", "設定", "Chrome")), LinearLayout.LayoutParams(0, dp(tileHeight), 1f).apply { leftMargin = dp(6); topMargin = dp(12) })
        folderColumn.addView(secondRow)
        main.addView(folderColumn, LinearLayout.LayoutParams(0, -2, 1f))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glass(32f, 86)
            setPadding(dp(4), dp(9), dp(4), dp(9))
        }
        val pinned = allApps.filter { dockPackages.contains(it.applicationInfo.packageName) }
        val defaults = allApps.filter { app ->
            val n = app.label.toString().lowercase(Locale.getDefault())
            (n.contains("電話") || n.contains("phone") || n.contains("gmail") || n.contains("chrome")) &&
                pinned.none { it.applicationInfo.packageName == app.applicationInfo.packageName }
        }
        val dockApps = (pinned + defaults).distinctBy { it.applicationInfo.packageName }.take(4)
        dockApps.forEach { app -> dock.addView(appIcon(app, 48), LinearLayout.LayoutParams(dp(54), dp(58)).apply { bottomMargin = dp(5) }) }
        dock.addView(label("•••", 17f, Color.WHITE), LinearLayout.LayoutParams(dp(52), dp(25)))
        dock.setOnClickListener { showDrawer("") }
        val dockHeight = (resources.configuration.screenHeightDp * 0.38f).toInt().coerceIn(260, 340)
        main.addView(dock, LinearLayout.LayoutParams(dp(62), dp(dockHeight)).apply { leftMargin = dp(9) })
        body.addView(main)

        val discover = label("所有 App　⌄", 13f, Color.WHITE, true).apply {
            background = glass(18f, 45)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { showDrawer("") }
        }
        body.addView(discover, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(16) })
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val page = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        page.addView(label("◉", 17f), LinearLayout.LayoutParams(0, dp(34), 1f))
        page.addView(label("•     •", 17f, Color.LTGRAY), LinearLayout.LayoutParams(0, dp(34), 1f))
        val allButton = label("☷", 19f)
        allButton.setOnClickListener { showDrawer("") }
        page.addView(allButton, LinearLayout.LayoutParams(0, dp(34), 1f))
        root.addView(page)

        search.setOnClickListener { showDrawer(search.text.toString()) }
        search.setOnEditorActionListener { _, _, _ -> showDrawer(search.text.toString()); true }
    }

    private fun folder(title: String, samples: List<String>): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glass(25f, 74)
            setPadding(dp(5), dp(8), dp(5), dp(7))
        }
        panel.addView(label(title, 13f, Color.WHITE, true), LinearLayout.LayoutParams(-1, dp(27)))
        val grid = GridLayout(this).apply { columnCount = 2; rowCount = 2 }
        samples.forEach { sample ->
            val app = allApps.firstOrNull { it.label.toString().contains(sample, true) }
            val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            if (app != null) {
                val icon = ImageView(this).apply { setImageDrawable(app.getIcon(0)); scaleType = ImageView.ScaleType.FIT_CENTER }
                tile.addView(icon, LinearLayout.LayoutParams(dp(34), dp(34)))
            } else {
                tile.addView(label(sample.take(2), 12f, Color.WHITE, true), LinearLayout.LayoutParams(dp(34), dp(34)))
            }
            grid.addView(tile, ViewGroup.LayoutParams(dp(49), dp(49)))
        }
        panel.addView(grid)
        panel.setOnClickListener { showDrawer("", title) }
        return panel
    }

    private fun matchesCategory(info: LauncherActivityInfo, category: String?): Boolean {
        if (category == null) return true
        val value = (info.label.toString() + " " + info.applicationInfo.packageName).lowercase(Locale.getDefault())
        val terms = when (category) {
            "社交" -> listOf("line", "facebook", "instagram", "messenger", "whatsapp", "telegram", "social", "x.android")
            "工具" -> listOf("file", "clock", "camera", "calculator", "chrome", "browser", "settings", "tool")
            "效率與財務" -> listOf("calendar", "finance", "bank", "wallet", "pay", "calculator", "行事曆", "銀行", "支付", "計算機")
            "建議" -> listOf("settings", "play", "photo", "gallery", "相簿", "設定")
            else -> emptyList()
        }
        return terms.any { value.contains(it) }
    }


    private fun appIcon(info: LauncherActivityInfo, size: Int): View {
        val frame = LinearLayout(this).apply { gravity = Gravity.CENTER; isClickable = true; isFocusable = true }
        val icon = ImageView(this).apply { setImageDrawable(info.getIcon(0)); scaleType = ImageView.ScaleType.FIT_CENTER }
        frame.addView(icon, LinearLayout.LayoutParams(dp(size - 6), dp(size - 6)))
        frame.setOnClickListener { launch(info) }
        frame.setOnLongClickListener { showAppOptions(info); true }
        return frame
    }

    private fun launch(info: LauncherActivityInfo) {
        try {
            launcherApps.startMainActivity(info.componentName, info.user, null, null)
        } catch (_: Exception) {
            Toast.makeText(this, "無法開啟此 App", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppOptions(info: LauncherActivityInfo) {
        val pkg = info.applicationInfo.packageName
        val pinned = dockPackages.contains(pkg)
        AlertDialog.Builder(this)
            .setTitle(info.label)
            .setItems(arrayOf(if (pinned) "從 Dock 移除" else "加入右側 Dock", "App 資訊")) { _, which ->
                if (which == 0) {
                    if (pinned) dockPackages.remove(pkg) else dockPackages.add(pkg)
                    prefs.edit().putStringSet("dock", dockPackages.toSet()).apply()
                    if (drawerOpen) showDrawer(drawerQuery, drawerCategory) else buildHome()
                } else {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$pkg")))
                }
            }.show()
    }

    private fun showDrawer(query: String, category: String? = null) {
        drawerOpen = true
        drawerQuery = query
        drawerCategory = category
        makeRoot()
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("App 資源庫", 23f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(46), 1f))
        top.addView(label("⌂", 27f).apply { setOnClickListener { buildHome() } }, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(top)
        val input = EditText(this).apply {
            hint = "搜尋已安裝的 App"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(true)
            setPadding(dp(14), 0, dp(14), 0)
            background = glass(20f, 70)
            setText(query)
            setSelection(text.length)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(49)).apply { topMargin = dp(8); bottomMargin = dp(10) })
        val scroll = ScrollView(this)
        val columns = if (resources.configuration.screenWidthDp >= 420) 5 else 4
        val grid = GridLayout(this).apply { columnCount = columns; useDefaultMargins = true }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun populate(q: String) {
            grid.removeAllViews()
            allApps.filter { it.label.toString().contains(q, true) && matchesCategory(it, drawerCategory) }.forEach { info ->
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), dp(6), dp(2), dp(6)) }
                cell.addView(appIcon(info, 52), LinearLayout.LayoutParams(dp(60), dp(58)))
                cell.addView(label(info.label.toString(), 10f, Color.WHITE), LinearLayout.LayoutParams(dp(72), dp(29)))
                cell.setOnLongClickListener { showAppOptions(info); true }
                grid.addView(cell, GridLayout.LayoutParams().apply {
                    width = 0
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                })
            }
        }
        populate(query)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                drawerQuery = s?.toString() ?: ""
                if (drawerQuery.isNotEmpty()) drawerCategory = null
                populate(drawerQuery)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }
}
