# Build a Debug APK in the cloud (no computer / Android Studio required)

This project includes a GitHub Actions workflow at `.github/workflows/build-debug-apk.yml`.

## From an Android phone
1. Sign in to GitHub in your phone browser and create a **private** repository.
2. Upload the contents of this project ZIP to the repository's `main` branch. Keep the `.github/workflows/build-debug-apk.yml` path intact. If the mobile upload UI hides dot-folders, use GitHub's web editor to create the workflow file at that exact path.
3. Open the repository's **Actions** tab and select **Build iPhone Duo Debug APK**.
4. Wait for the run to finish successfully. Open the run, find **Artifacts**, and download `iPhoneDuo-Xperia1V-debug-apk`.
5. Extract the artifact ZIP on the phone and tap the `.apk` file to install. Android may ask you to allow installs from that browser or file manager.

The workflow uses GitHub-hosted runners to install JDK 17, Gradle 8.9 and Android SDK platform 35, then runs `gradle assembleDebug`. The resulting debug APK is for testing, not Play Store release.

## Important
- Keep the repository private if you do not want the source code public.
- Do not put passwords, signing keys, tokens, or personal data in the repository.
- A successful cloud build is not the same as device testing. Verify launcher selection, app launch, screen insets, and folder interactions on the Xperia 1 V.
